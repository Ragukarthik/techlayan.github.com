<?php
	$conn = new mysqli('localhost', 'root', '', 'student') or die(mysqli_error());
	if(!$conn){
		die("Fatal Error: Connection Failed!");
	}