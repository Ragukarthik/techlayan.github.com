<?php
	session_start();
	session_unset($_SESSION['admin_id']);
	
	
	session_destroy();
	echo "<script>window.open('adminpage.php','_self');</script>";
	?>